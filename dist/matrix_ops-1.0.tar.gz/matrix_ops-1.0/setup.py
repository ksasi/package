from setuptools import setup

setup(name='matrix_ops',
      version='1.0',
      description='Martix Operations',
      packages=['matrix_ops'],
      zip_safe=False)